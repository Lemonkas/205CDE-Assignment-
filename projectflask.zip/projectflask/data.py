def Articles():
	articles = [
       {
           'id':1,
           'title': 'Artile One',
           'body': 'Write sth',
           'author': '(Name)',
           'create_data':'March 29,2022'
       },
       {
           'id':2,
           'title': 'Artile Two',
           'body': 'Write sth',
           'author': '(Name)',
           'create_data':'March 30,2022'
       },
       {
           'id':3,
           'title': 'Artile Three',
           'body': 'Write sth',
           'author': '(Name)',
           'create_data':'March 31,2022'
       }
	]
	return articles